export const cleanFloatPrecision = (num: number): number => {
  if (!isFinite(num)) return num;
  return parseFloat(num.toPrecision(12));
};

export const formatDisplayNumber = (
  numStr: string,
  separator: ',' | '.' = ','
): string => {
  if (numStr === 'Erro' || numStr === 'Indefinido') return numStr;
  
  // If user is currently typing a decimal point at the end
  const hasTrailingDot = numStr.endsWith('.') || numStr.endsWith(',');
  const parts = numStr.replace(',', '.').split('.');

  const integerPart = parts[0];
  const decimalPart = parts[1];

  // Format integer with thousands separators
  const formattedInteger = Number(integerPart).toLocaleString(
    separator === ',' ? 'pt-BR' : 'en-US',
    { maximumFractionDigits: 0 }
  );

  if (isNaN(Number(integerPart))) {
    return numStr;
  }

  if (hasTrailingDot) {
    return `${formattedInteger}${separator}`;
  }

  if (decimalPart !== undefined) {
    return `${formattedInteger}${separator}${decimalPart}`;
  }

  return formattedInteger;
};

export const evaluateBasic = (
  firstOperand: number,
  secondOperand: number,
  operation: '+' | '−' | '×' | '÷'
): number => {
  switch (operation) {
    case '+':
      return cleanFloatPrecision(firstOperand + secondOperand);
    case '−':
      return cleanFloatPrecision(firstOperand - secondOperand);
    case '×':
      return cleanFloatPrecision(firstOperand * secondOperand);
    case '÷':
      if (secondOperand === 0) {
        throw new Error('Divisão por zero');
      }
      return cleanFloatPrecision(firstOperand / secondOperand);
    default:
      return secondOperand;
  }
};
