import React, { useState } from 'react';
import { Header, AppTab } from './components/Header';
import { TraditionalCalculator } from './components/TraditionalCalculator';
import { Terminal } from './components/Terminal';
import { CodeViewer } from './components/CodeViewer';
import { TestRunner } from './components/TestRunner';
import { ArchitectureGuide } from './components/ArchitectureGuide';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('calculator');

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Bar following Frontend Design Constitution Contract */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Workspace Canvas */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'calculator' && <TraditionalCalculator />}
        {activeTab === 'terminal' && <Terminal />}
        {activeTab === 'code' && <CodeViewer />}
        {activeTab === 'tests' && <TestRunner />}
        {activeTab === 'architecture' && <ArchitectureGuide />}
      </main>

      {/* Subtle, Clean Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/60 py-4 px-6 text-center text-xs text-slate-400">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Calculadora Tradicional & Interativa · Estilo Smartphone & Desktop
          </span>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Suporte a Teclado Físico</span>
            <span aria-hidden="true">·</span>
            <span>Fita de Histórico</span>
            <span aria-hidden="true">·</span>
            <span>Modo Científico</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
