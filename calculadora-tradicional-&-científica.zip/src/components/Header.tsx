import React from 'react';
import { Download, Calculator } from 'lucide-react';
import { CALCULADORA_PY } from '../data/pythonCode';

export type AppTab = 'calculator' | 'terminal' | 'code' | 'tests' | 'architecture';

interface HeaderProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const downloadScript = () => {
    const blob = new Blob([CALCULADORA_PY], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'calculadora.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 border-b border-slate-800 text-slate-100">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Calculator className="w-4 h-4" />
          </div>
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            Calculadora
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links (Single-Line, clean segmented) */}
      <nav className="hidden md:flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('calculator')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'calculator'
              ? 'text-white bg-slate-800 shadow-sm font-semibold'
              : 'hover:text-slate-200'
          }`}
        >
          Calculadora Tradicional
        </button>
        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'terminal'
              ? 'text-white bg-slate-800 shadow-sm font-semibold'
              : 'hover:text-slate-200'
          }`}
        >
          Terminal Python
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'code'
              ? 'text-white bg-slate-800 shadow-sm font-semibold'
              : 'hover:text-slate-200'
          }`}
        >
          Código Python
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'tests'
              ? 'text-white bg-slate-800 shadow-sm font-semibold'
              : 'hover:text-slate-200'
          }`}
        >
          Testes Unitários
        </button>
        <button
          onClick={() => setActiveTab('architecture')}
          className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'architecture'
              ? 'text-white bg-slate-800 shadow-sm font-semibold'
              : 'hover:text-slate-200'
          }`}
        >
          Arquitetura
        </button>
      </nav>

      {/* Mobile Nav Dropdown or Segmented for Small screens */}
      <div className="flex md:hidden items-center gap-1">
        <button
          onClick={() => setActiveTab('calculator')}
          className={`px-2.5 py-1 text-xs rounded ${activeTab === 'calculator' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'}`}
        >
          Calculadora
        </button>
        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-2.5 py-1 text-xs rounded ${activeTab === 'terminal' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'}`}
        >
          Python
        </button>
      </div>

      {/* Zone 3: 1 Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={downloadScript}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors whitespace-nowrap shrink-0 shadow-sm active:scale-95"
          title="Baixar script calculadora.py"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Baixar .py</span>
        </button>
      </div>
    </header>
  );
};
