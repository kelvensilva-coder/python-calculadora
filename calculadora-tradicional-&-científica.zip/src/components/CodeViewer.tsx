import React, { useState } from 'react';
import { Copy, Check, Download, FileCode, CheckCircle2 } from 'lucide-react';
import { CALCULADORA_PY } from '../data/pythonCode';

export const CodeViewer: React.FC = () => {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(CALCULADORA_PY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([CALCULADORA_PY], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'calculadora.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Quick syntax highlighting token generator for Python
  const renderHighlightedCode = () => {
    const lines = CALCULADORA_PY.split('\n');

    return lines.map((line, idx) => {
      let content: React.ReactNode = line;

      // Comment
      if (line.trim().startsWith('#')) {
        content = <span className="text-slate-400 italic">{line}</span>;
      } else if (line.trim().startsWith('"""') || line.trim().startsWith('r"""')) {
        content = <span className="text-emerald-300 italic">{line}</span>;
      } else {
        // Highlight def, return, while, try, except, if, elif, else, break, continue, import, from
        const tokens = line.split(/(\bdef\b|\breturn\b|\bwhile\b|\btry\b|\bexcept\b|\bif\b|\belif\b|\belse\b|\bbreak\b|\bcontinue\b|\bimport\b|\bfrom\b|\bTrue\b|\bFalse\b|\bNone\b|\bfloat\b|\bstr\b|\bint\b|\bCallable\b|\bDict\b|\bTuple\b)/g);
        
        content = tokens.map((tok, tIdx) => {
          if (['def', 'return', 'while', 'try', 'except', 'if', 'elif', 'else', 'break', 'continue', 'import', 'from'].includes(tok)) {
            return <span key={tIdx} className="text-purple-400 font-semibold">{tok}</span>;
          }
          if (['True', 'False', 'None'].includes(tok)) {
            return <span key={tIdx} className="text-amber-400 font-semibold">{tok}</span>;
          }
          if (['float', 'str', 'int', 'Callable', 'Dict', 'Tuple'].includes(tok)) {
            return <span key={tIdx} className="text-sky-400 font-medium">{tok}</span>;
          }
          if (tok.includes('ZeroDivisionError') || tok.includes('ValueError') || tok.includes('KeyboardInterrupt')) {
            return <span key={tIdx} className="text-rose-400 font-medium">{tok}</span>;
          }
          return tok;
        });
      }

      return (
        <div key={idx} className="flex hover:bg-slate-800/40 px-3 py-0.5 leading-relaxed">
          <span className="w-10 text-right pr-4 text-slate-400 select-none font-mono text-xs tabular-nums opacity-60">
            {idx + 1}
          </span>
          <span className="flex-1 font-mono text-xs sm:text-sm text-slate-200 whitespace-pre">
            {content}
          </span>
        </div>
      );
    });
  };

  return (
    <div className="space-y-4">
      {/* Code Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded-lg">
        <div className="flex items-center gap-2.5">
          <FileCode className="w-4 h-4 text-emerald-400" />
          <span className="font-mono text-sm font-semibold text-white">calculadora.py</span>
          <span className="text-xs text-slate-400 font-sans hidden sm:inline">
            · Padrão PEP 8 · Tipagem Estrita · Docstrings Completas
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Código Copiado!' : 'Copiar Código'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-500 hover:bg-emerald-400 text-xs font-semibold text-slate-950 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Baixar .py</span>
          </button>
        </div>
      </div>

      {/* Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Vírgula & Ponto</span>
          </div>
          <p className="text-[12px] text-slate-300">
            Linha 35: <code className="bg-slate-800 px-1 py-0.5 rounded text-emerald-300">.replace(",", ".")</code> elimina o erro comum de conversão float no Brasil.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Validação Resiliente</span>
          </div>
          <p className="text-[12px] text-slate-300">
            Linhas 40-57: Função <code className="bg-slate-800 px-1 py-0.5 rounded text-sky-300">solicitar_numero()</code> em loop para nunca quebrar o programa.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Divisão por Zero</span>
          </div>
          <p className="text-[12px] text-slate-300">
            Linha 82 e 160: Captura de <code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300">ZeroDivisionError</code> pedindo novo divisor com aviso claro.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-lg space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Formatação Inteligente</span>
          </div>
          <p className="text-[12px] text-slate-300">
            Linha 98: <code className="bg-slate-800 px-1 py-0.5 rounded text-purple-300">valor.is_integer()</code> exibe '13' para inteiros e '3.33' para decimais.
          </p>
        </div>
      </div>

      {/* Code Display Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden shadow-xl">
        <div className="py-3 overflow-x-auto terminal-scroll max-h-[600px]">
          {renderHighlightedCode()}
        </div>
      </div>
    </div>
  );
};
