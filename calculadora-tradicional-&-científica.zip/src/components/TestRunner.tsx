import React, { useState } from 'react';
import { Play, CheckCircle, Download, Copy, Check, ShieldCheck, Terminal as TerminalIcon } from 'lucide-react';
import { TEST_CALCULADORA_PY } from '../data/pythonCode';
import { UnitTestItem } from '../types';

export const TestRunner: React.FC = () => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [testResults, setTestResults] = useState<Record<string, { passed: boolean; actual: string }>>({});
  const [activeTab, setActiveTab] = useState<'interactive' | 'source'>('interactive');
  const [copied, setCopied] = useState<boolean>(false);

  const parseNumberFlexible = (raw: string): number => {
    const cleaned = raw.trim().replace(',', '.');
    if (cleaned === '' || isNaN(Number(cleaned))) {
      throw new Error('ValueError');
    }
    return parseFloat(cleaned);
  };

  const formatResult = (val: number): string => {
    if (Number.isInteger(val)) {
      return val.toString();
    }
    const rounded = Number(val.toFixed(2));
    if (Number.isInteger(rounded)) {
      return rounded.toString();
    }
    return val.toFixed(2);
  };

  const testSuite: UnitTestItem[] = [
    {
      id: 'test_virgula_padrao_br',
      name: 'test_conversao_com_virgula',
      category: 'Parsing & Normalização',
      description: 'Aceita decimais com vírgula (ex: "10,5" -> 10.5)',
      expected: '10.5',
      run: () => {
        const res = parseNumberFlexible('10,5');
        return { passed: res === 10.5, actual: res.toString() };
      },
    },
    {
      id: 'test_ponto_padrao_intl',
      name: 'test_conversao_com_ponto',
      category: 'Parsing & Normalização',
      description: 'Aceita decimais com ponto (ex: "10.5" -> 10.5)',
      expected: '10.5',
      run: () => {
        const res = parseNumberFlexible('10.5');
        return { passed: res === 10.5, actual: res.toString() };
      },
    },
    {
      id: 'test_espacos_laterais',
      name: 'test_conversao_com_espacos',
      category: 'Parsing & Normalização',
      description: 'Limpa espaços em branco acidentais (.strip)',
      expected: '15.4',
      run: () => {
        const res = parseNumberFlexible('   15,4   ');
        return { passed: res === 15.4, actual: res.toString() };
      },
    },
    {
      id: 'test_leitura_inteiro',
      name: 'test_conversao_inteiro',
      category: 'Parsing & Normalização',
      description: 'Aceita números inteiros como string (ex: "42" -> 42.0)',
      expected: '42',
      run: () => {
        const res = parseNumberFlexible('42');
        return { passed: res === 42, actual: res.toString() };
      },
    },
    {
      id: 'test_entrada_invalida_string',
      name: 'test_entrada_invalida_lanca_value_error',
      category: 'Tratamento de Exceções',
      description: 'Entrada "abc" dispara ValueError sem quebrar o programa',
      expected: 'ValueError capturado',
      run: () => {
        try {
          parseNumberFlexible('abc');
          return { passed: false, actual: 'Não levantou erro!' };
        } catch {
          return { passed: true, actual: 'ValueError capturado' };
        }
      },
    },
    {
      id: 'test_divisao_por_zero',
      name: 'test_divisao_por_zero_lanca_excecao',
      category: 'Tratamento de Exceções',
      description: 'Divisão por 0 dispara ZeroDivisionError controlado',
      expected: 'ZeroDivisionError capturado',
      run: () => {
        const div = (a: number, b: number) => {
          if (b === 0) throw new Error('ZeroDivisionError');
          return a / b;
        };
        try {
          div(10, 0);
          return { passed: false, actual: 'Não disparou exceção!' };
        } catch {
          return { passed: true, actual: 'ZeroDivisionError capturado' };
        }
      },
    },
    {
      id: 'test_operacao_soma',
      name: 'test_somar_com_decimais',
      category: 'Operações Aritméticas',
      description: 'Soma de 10.5 + 2.5 resulta em 13.0',
      expected: '13',
      run: () => {
        const res = 10.5 + 2.5;
        return { passed: res === 13, actual: res.toString() };
      },
    },
    {
      id: 'test_operacao_subtracao',
      name: 'test_subtrair_com_decimais',
      category: 'Operações Aritméticas',
      description: 'Subtração de 10.5 - 3.2 resulta em 7.3',
      expected: '7.3',
      run: () => {
        const res = Number((10.5 - 3.2).toFixed(1));
        return { passed: res === 7.3, actual: res.toString() };
      },
    },
    {
      id: 'test_operacao_multiplicacao',
      name: 'test_multiplicar_com_decimais',
      category: 'Operações Aritméticas',
      description: 'Multiplicação de 4.0 * 2.5 resulta em 10.0',
      expected: '10',
      run: () => {
        const res = 4 * 2.5;
        return { passed: res === 10, actual: res.toString() };
      },
    },
    {
      id: 'test_formato_inteiro_exato',
      name: 'test_formatar_resultado_inteiro',
      category: 'Formatação de Saída',
      description: 'Valores inteiros exatos são exibidos sem ".0" (ex: "13")',
      expected: '"13"',
      run: () => {
        const formatted = formatResult(13.0);
        return { passed: formatted === '13', actual: `"${formatted}"` };
      },
    },
    {
      id: 'test_formato_decimal_2_casas',
      name: 'test_formatar_resultado_decimal',
      category: 'Formatação de Saída',
      description: 'Decimais periódicos arredondados para 2 casas (ex: 10/3 -> "3.33")',
      expected: '"3.33"',
      run: () => {
        const formatted = formatResult(10 / 3);
        return { passed: formatted === '3.33', actual: `"${formatted}"` };
      },
    },
  ];

  const runAllTests = async () => {
    setIsRunning(true);
    const results: Record<string, { passed: boolean; actual: string }> = {};

    for (const test of testSuite) {
      await new Promise((r) => setTimeout(r, 60));
      const res = test.run();
      results[test.id] = res;
      setTestResults({ ...results });
    }

    setIsRunning(false);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(TEST_CALCULADORA_PY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTests = () => {
    const blob = new Blob([TEST_CALCULADORA_PY], { type: 'text/x-python;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'test_calculadora.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const totalRun = Object.keys(testResults).length;
  const passedCount = Object.values(testResults).filter((r) => r.passed).length;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <div>
            <h2 className="text-sm font-semibold text-white">
              Suíte de Testes Automatizados (unittest)
            </h2>
            <p className="text-xs text-slate-400">
              Validação rigorosa de cada um dos 4 requisitos especificados pelo usuário
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex items-center bg-slate-800 p-0.5 rounded-md text-xs">
            <button
              onClick={() => setActiveTab('interactive')}
              className={`px-3 py-1.5 rounded transition-colors ${
                activeTab === 'interactive' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
            >
              Execução Interativa
            </button>
            <button
              onClick={() => setActiveTab('source')}
              className={`px-3 py-1.5 rounded transition-colors ${
                activeTab === 'source' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
            >
              Código do Teste (.py)
            </button>
          </div>

          <button
            onClick={runAllTests}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs transition-colors shadow-sm disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isRunning ? 'Executando Testes...' : 'Executar Todos os Testes'}</span>
          </button>
        </div>
      </div>

      {activeTab === 'interactive' ? (
        <div className="space-y-3">
          {/* Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400">Total de Casos de Teste</span>
              <div className="text-lg font-bold font-mono text-white mt-0.5">
                {testSuite.length}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400">Testes Aprovados</span>
              <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">
                {passedCount} / {testSuite.length}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400">Taxa de Sucesso</span>
              <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">
                {totalRun > 0 ? `${Math.round((passedCount / totalRun) * 100)}%` : '100%'}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
              <span className="text-[11px] text-slate-400">Framework Python</span>
              <div className="text-sm font-semibold font-mono text-purple-300 mt-1">
                unittest.TestCase
              </div>
            </div>
          </div>

          {/* Test Items Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
            <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Método de Teste & Descrição</span>
              <span>Status & Resultado</span>
            </div>
            <div className="divide-y divide-slate-800/60 font-mono text-xs">
              {testSuite.map((item) => {
                const result = testResults[item.id];
                return (
                  <div key={item.id} className="p-3 flex flex-wrap items-center justify-between gap-2 hover:bg-slate-800/30 transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-purple-400 font-semibold">{item.name}()</span>
                        <span className="text-[11px] text-slate-400 font-sans">
                          [{item.category}]
                        </span>
                      </div>
                      <p className="text-[12px] text-slate-400 font-sans">
                        {item.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-[11px] text-slate-400">
                          Esperado: <span className="text-slate-300">{item.expected}</span>
                        </div>
                        {result && (
                          <div className="text-[11px] text-slate-400">
                            Obtido: <span className="text-white">{result.actual}</span>
                          </div>
                        )}
                      </div>

                      {result ? (
                        result.passed ? (
                          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400 font-sans text-xs font-semibold">
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>PASSED</span>
                          </div>
                        ) : (
                          <div className="px-2.5 py-1 rounded bg-rose-950/80 border border-rose-800 text-rose-400 font-sans text-xs font-semibold">
                            FAILED
                          </div>
                        )
                      ) : (
                        <div className="px-2.5 py-1 rounded bg-slate-800 text-slate-400 font-sans text-xs">
                          Pronto
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-lg">
            <div className="flex items-center gap-2 font-mono text-xs text-white">
              <TerminalIcon className="w-4 h-4 text-emerald-400" />
              <span>test_calculadora.py</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado!' : 'Copiar'}</span>
              </button>
              <button
                onClick={handleDownloadTests}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar test_calculadora.py</span>
              </button>
            </div>
          </div>

          <pre className="p-4 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-200 overflow-x-auto terminal-scroll max-h-[500px] leading-relaxed">
            {TEST_CALCULADORA_PY}
          </pre>
        </div>
      )}
    </div>
  );
};
