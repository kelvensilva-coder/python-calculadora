import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal as TerminalIcon, 
  RotateCcw, 
  Trash2, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Play,
  Sparkles,
  Info
} from 'lucide-react';
import { TerminalLine, CalcStep, TerminalTheme } from '../types';
import { sound } from '../utils/audio';

export const Terminal: React.FC = () => {
  const [theme, setTheme] = useState<TerminalTheme>('dark');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Program State Machine
  const [step, setStep] = useState<CalcStep>('SELECT_OPTION');
  const [selectedOpKey, setSelectedOpKey] = useState<string>('1');
  const [num1, setNum1] = useState<number | null>(null);

  // Input & Terminal Content
  const [currentInput, setCurrentInput] = useState<string>('');
  const [inputHistory, setInputHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  const [lines, setLines] = useState<TerminalLine[]>([]);
  const terminalBottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const operationsConfig: Record<string, { symbol: string; name: string; calc: (a: number, b: number) => number }> = {
    '1': { symbol: '+', name: 'Adição', calc: (a, b) => a + b },
    '2': { symbol: '-', name: 'Subtração', calc: (a, b) => a - b },
    '3': { symbol: '*', name: 'Multiplicação', calc: (a, b) => a * b },
    '4': { symbol: '/', name: 'Divisão', calc: (a, b) => {
      if (b === 0) throw new Error('ZeroDivisionError');
      return a / b;
    }},
  };

  const formatResult = (val: number): string => {
    // Se for inteiro exato (ex: 13.0), exibe como inteiro
    if (Number.isInteger(val)) {
      return val.toString();
    }
    // Caso decimal, arredonda para no máximo 2 casas decimais
    const rounded = Number(val.toFixed(2));
    if (Number.isInteger(rounded)) {
      return rounded.toString();
    }
    return val.toFixed(2);
  };

  const parseNumberFlexible = (raw: string): number => {
    const cleaned = raw.trim().replace(',', '.');
    if (cleaned === '' || isNaN(Number(cleaned))) {
      throw new Error('ValueError');
    }
    return parseFloat(cleaned);
  };

  // Helper to add lines
  const pushLines = (newLines: Omit<TerminalLine, 'id'>[]) => {
    const timestamp = new Date().toLocaleTimeString('pt-BR', { hour12: false });
    const formatted = newLines.map((l) => ({
      ...l,
      id: Math.random().toString(36).substring(2, 9),
      timestamp,
    }));
    setLines((prev) => [...prev, ...formatted]);
  };

  const renderMenuLines = () => {
    return [
      { type: 'divider' as const, text: '------------------------------------------------------' },
      { type: 'menu' as const, text: '  OPERAÇÕES DISPONÍVEIS:' },
      { type: 'menu' as const, text: '  [1] Adição (+)' },
      { type: 'menu' as const, text: '  [2] Subtração (-)' },
      { type: 'menu' as const, text: '  [3] Multiplicação (*)' },
      { type: 'menu' as const, text: '  [4] Divisão (/)' },
      { type: 'menu' as const, text: '  [5] Sair do Programa (ou digite \'sair\')' },
      { type: 'divider' as const, text: '------------------------------------------------------' },
    ];
  };

  // Restart Python Program
  const restartProgram = () => {
    setStep('SELECT_OPTION');
    setSelectedOpKey('1');
    setNum1(null);
    setCurrentInput('');
    setLines([
      { id: '1', type: 'system', text: '$ python3 calculadora.py' },
      { id: '2', type: 'divider', text: '======================================================' },
      { id: '3', type: 'system', text: '         CALCULADORA INTERATIVA VIA TERMINAL' },
      { id: '4', type: 'system', text: '   Engenharia de Software Python | Padrão PEP 8' },
      { id: '5', type: 'divider', text: '======================================================' },
      ...renderMenuLines().map((l) => ({ ...l, id: Math.random().toString(36) })),
    ]);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  // Initial startup
  useEffect(() => {
    restartProgram();
  }, []);

  // Scroll to bottom on new lines
  useEffect(() => {
    terminalBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines, step]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
    if (next) sound.playSuccess();
  };

  const getPromptText = () => {
    switch (step) {
      case 'SELECT_OPTION':
        return ">> Digite a opção (1-5 ou 'sair'): ";
      case 'INPUT_NUM1':
        return '>> Digite o primeiro número: ';
      case 'INPUT_NUM2':
        return '>> Digite o segundo número: ';
      case 'TERMINATED':
        return '>> Programa finalizado. Pressione "Reiniciar" ou digite reiniciar: ';
      default:
        return '>> ';
    }
  };

  const handleCommand = (rawVal: string) => {
    const val = rawVal.trim();
    if (!val && step !== 'SELECT_OPTION') return;

    sound.playEnter();

    // Store in history
    if (val) {
      setInputHistory((prev) => [...prev, val]);
      setHistoryIndex(-1);
    }

    // Print the user's input line
    pushLines([{ type: 'input', text: `${getPromptText()}${val}` }]);
    setCurrentInput('');

    // Handle Restart if terminated
    if (step === 'TERMINATED') {
      if (val.toLowerCase() === 'reiniciar' || val.toLowerCase() === 'restart' || val === '1') {
        restartProgram();
      } else {
        pushLines([
          { type: 'system', text: 'Para iniciar novamente, digite "reiniciar" ou clique no botão Reiniciar acima.' }
        ]);
      }
      return;
    }

    // 1. SELECT_OPTION
    if (step === 'SELECT_OPTION') {
      const lower = val.toLowerCase();
      if (['5', 'sair', 'exit', 'q', 'quit'].includes(lower)) {
        pushLines([
          { type: 'divider', text: '======================================================' },
          { type: 'system', text: '  Programa finalizado com sucesso. Até logo!' },
          { type: 'divider', text: '======================================================' },
          { type: 'system', text: 'Process finished with exit code 0.' },
        ]);
        setStep('TERMINATED');
        sound.playSuccess();
        return;
      }

      if (!['1', '2', '3', '4'].includes(val)) {
        sound.playError();
        pushLines([
          { type: 'error', text: `  [OPÇÃO INVÁLIDA] '${val}' não foi reconhecida.` },
          { type: 'error', text: "  Escolha uma opção entre 1 e 5 ou digite 'sair'." },
        ]);
        return;
      }

      const op = operationsConfig[val];
      setSelectedOpKey(val);
      pushLines([
        { type: 'output', text: `\n>> Operação Selecionada: ${op.name} (${op.symbol})` },
      ]);
      setStep('INPUT_NUM1');
      return;
    }

    // 2. INPUT_NUM1
    if (step === 'INPUT_NUM1') {
      try {
        const parsed = parseNumberFlexible(val);
        setNum1(parsed);
        setStep('INPUT_NUM2');
      } catch {
        sound.playError();
        pushLines([
          { type: 'error', text: `  [ERRO DE ENTRADA] '${val}' não é um número válido!` },
          { type: 'error', text: '  Por favor, digite um número inteiro ou decimal (Ex: 10, 10.5, 10,5, -3)' },
          { type: 'error', text: '  Tente novamente.' },
        ]);
      }
      return;
    }

    // 3. INPUT_NUM2
    if (step === 'INPUT_NUM2') {
      try {
        const parsed2 = parseNumberFlexible(val);
        const op = operationsConfig[selectedOpKey];

        if (num1 === null) {
          setStep('SELECT_OPTION');
          return;
        }

        try {
          const result = op.calc(num1, parsed2);
          const n1Fmt = formatResult(num1);
          const n2Fmt = formatResult(parsed2);
          const resFmt = formatResult(result);

          sound.playSuccess();
          pushLines([
            { type: 'divider', text: '======================================================' },
            { type: 'success', text: `  RESULTADO: ${n1Fmt} ${op.symbol} ${n2Fmt} = ${resFmt}` },
            { type: 'divider', text: '======================================================' },
            ...renderMenuLines(),
          ]);

          // Reset for next operation in the while loop
          setNum1(null);
          setStep('SELECT_OPTION');
        } catch {
          // Zero division
          sound.playError();
          pushLines([
            { type: 'error', text: '  [ERRO DE ARITMÉTICA] Não é possível dividir um número por zero (0)!' },
            { type: 'error', text: '  Por favor, informe um divisor válido diferente de zero.' },
          ]);
          // Remains in INPUT_NUM2 step
        }
      } catch {
        sound.playError();
        pushLines([
          { type: 'error', text: `  [ERRO DE ENTRADA] '${val}' não é um número válido!` },
          { type: 'error', text: '  Por favor, digite um número inteiro ou decimal (Ex: 10, 10.5, 10,5, -3)' },
          { type: 'error', text: '  Tente novamente.' },
        ]);
      }
      return;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    sound.playKey();

    if (e.key === 'Enter') {
      e.preventDefault();
      handleCommand(currentInput);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (inputHistory.length > 0) {
        const nextIdx = historyIndex + 1;
        if (nextIdx < inputHistory.length) {
          setHistoryIndex(nextIdx);
          setCurrentInput(inputHistory[inputHistory.length - 1 - nextIdx]);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIdx = historyIndex - 1;
        setHistoryIndex(nextIdx);
        setCurrentInput(inputHistory[inputHistory.length - 1 - nextIdx]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCurrentInput('');
      }
    } else if (e.ctrlKey && e.key === 'l') {
      e.preventDefault();
      clearTerminal();
    }
  };

  const clearTerminal = () => {
    setLines([
      { id: Math.random().toString(), type: 'system', text: 'Terminal limpo (Ctrl+L).' }
    ]);
  };

  const copySession = () => {
    const text = lines.map((l) => l.text).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Quick execution helper for test chips
  const runPresetSequence = async (inputs: string[]) => {
    for (const item of inputs) {
      await new Promise((r) => setTimeout(r, 220));
      handleCommand(item);
    }
  };

  // Theme styling classes
  const themeClasses: Record<TerminalTheme, { bg: string; border: string; text: string; header: string }> = {
    dark: {
      bg: 'bg-slate-950',
      border: 'border-slate-800',
      text: 'text-slate-100',
      header: 'bg-slate-900 border-slate-800 text-slate-300',
    },
    matrix: {
      bg: 'bg-black',
      border: 'border-emerald-900',
      text: 'text-emerald-400',
      header: 'bg-emerald-950/60 border-emerald-900 text-emerald-400',
    },
    dracula: {
      bg: 'bg-[#1e1f29]',
      border: 'border-[#3b3e52]',
      text: 'text-[#f8f8f2]',
      header: 'bg-[#282a36] border-[#3b3e52] text-[#bd93f9]',
    },
    amber: {
      bg: 'bg-amber-950/95',
      border: 'border-amber-900/80',
      text: 'text-amber-300',
      header: 'bg-amber-950 border-amber-900 text-amber-400',
    },
  };

  const activeTheme = themeClasses[theme];

  return (
    <div className="space-y-4">
      {/* Top Controls & Status */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-200">Ambiente de Execução:</span>
          <span className="font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
            calculadora.py (interativo)
          </span>
          <span className="text-slate-400 hidden md:inline">
            Status: {step === 'TERMINATED' ? 'Encerrado (Exit 0)' : 'Em Execução (Loop While)'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme selector */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-md border border-slate-800">
            {(['dark', 'matrix', 'dracula', 'amber'] as TerminalTheme[]).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`px-2 py-1 rounded text-[11px] capitalize transition-colors ${
                  theme === t ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className={`p-1.5 rounded-md border transition-colors ${
              soundEnabled
                ? 'bg-emerald-950/60 border-emerald-700 text-emerald-400'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title={soundEnabled ? 'Áudio Habilitado (Clique para silenciar)' : 'Áudio Desabilitado (Clique para ativar)'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Copy Session */}
          <button
            onClick={copySession}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
            title="Copiar histórico completo do terminal"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copiado!' : 'Copiar'}</span>
          </button>

          {/* Clear */}
          <button
            onClick={clearTerminal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
            title="Limpar tela (Ctrl+L)"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Limpar</span>
          </button>

          {/* Restart */}
          <button
            onClick={restartProgram}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors"
            title="Reiniciar script Python do zero"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reiniciar</span>
          </button>
        </div>
      </div>

      {/* Main Terminal Window */}
      <div 
        className={`rounded-lg border shadow-xl overflow-hidden font-mono ${activeTheme.bg} ${activeTheme.border}`}
        onClick={() => inputRef.current?.focus()}
      >
        {/* Window Title Bar */}
        <div className={`flex items-center justify-between px-4 py-2 border-b select-none ${activeTheme.header}`}>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-mono ml-2">
              <TerminalIcon className="w-3.5 h-3.5 text-slate-400" />
              <span>bash - python3 calculadora.py</span>
            </div>
          </div>
          <div className="text-[11px] opacity-75">
            UTF-8 · Interactive TTY
          </div>
        </div>

        {/* Terminal Content Screen */}
        <div className={`p-4 h-[420px] overflow-y-auto terminal-scroll text-xs sm:text-sm leading-relaxed ${activeTheme.text}`}>
          {lines.map((line) => {
            if (line.type === 'error') {
              return (
                <div key={line.id} className="text-rose-400 whitespace-pre-wrap font-medium">
                  {line.text}
                </div>
              );
            }
            if (line.type === 'success') {
              return (
                <div key={line.id} className="text-emerald-400 whitespace-pre-wrap font-bold bg-emerald-950/20 py-0.5">
                  {line.text}
                </div>
              );
            }
            if (line.type === 'divider') {
              return (
                <div key={line.id} className="text-slate-600 whitespace-pre-wrap select-none">
                  {line.text}
                </div>
              );
            }
            if (line.type === 'menu') {
              return (
                <div key={line.id} className="text-sky-300 whitespace-pre-wrap">
                  {line.text}
                </div>
              );
            }
            if (line.type === 'input') {
              return (
                <div key={line.id} className="text-white whitespace-pre-wrap font-semibold">
                  {line.text}
                </div>
              );
            }
            return (
              <div key={line.id} className="whitespace-pre-wrap opacity-95">
                {line.text}
              </div>
            );
          })}

          {/* Active Input Line */}
          {step !== 'TERMINATED' ? (
            <div className="flex items-center gap-1 pt-1 text-white">
              <span className="text-emerald-400 shrink-0 font-bold">
                {getPromptText()}
              </span>
              <input
                ref={inputRef}
                type="text"
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-transparent border-none outline-none font-mono text-white p-0 text-xs sm:text-sm focus:ring-0"
                autoFocus
                spellCheck={false}
              />
            </div>
          ) : (
            <div className="flex items-center gap-2 pt-2 text-slate-400">
              <span>[Programa encerrado]</span>
              <button
                onClick={restartProgram}
                className="underline hover:text-white transition-colors"
              >
                Clique aqui para rodar novamente
              </button>
            </div>
          )}
          <div ref={terminalBottomRef} />
        </div>
      </div>

      {/* Preset Scenarios (Interactive Test Triggers) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Casos de Teste Rápidos (Clique para simular no terminal):</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Testa automaticamente as validações solicitadas
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 pt-1">
          <button
            onClick={() => {
              restartProgram();
              runPresetSequence(['1', '10,5', '2,5']);
            }}
            className="flex flex-col items-start p-2 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors group"
          >
            <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-400 group-hover:text-emerald-300">
              <Play className="w-3 h-3 fill-current" />
              <span>Vírgula Decimal</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5">
              10,5 + 2,5 = 13 (inteiro)
            </span>
          </button>

          <button
            onClick={() => {
              restartProgram();
              runPresetSequence(['4', '10', '3']);
            }}
            className="flex flex-col items-start p-2 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors group"
          >
            <div className="flex items-center gap-1.5 text-xs font-medium text-sky-400 group-hover:text-sky-300">
              <Play className="w-3 h-3 fill-current" />
              <span>Dízima Periódica</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5">
              10 / 3 = 3.33 (2 casas)
            </span>
          </button>

          <button
            onClick={() => {
              restartProgram();
              runPresetSequence(['4', '15', '0', '3']);
            }}
            className="flex flex-col items-start p-2 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors group"
          >
            <div className="flex items-center gap-1.5 text-xs font-medium text-rose-400 group-hover:text-rose-300">
              <Play className="w-3 h-3 fill-current" />
              <span>Divisão por Zero</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5">
              15 / 0 (ZeroDivisionError)
            </span>
          </button>

          <button
            onClick={() => {
              restartProgram();
              runPresetSequence(['1', 'abc', '10,5', '5']);
            }}
            className="flex flex-col items-start p-2 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors group"
          >
            <div className="flex items-center gap-1.5 text-xs font-medium text-amber-400 group-hover:text-amber-300">
              <Play className="w-3 h-3 fill-current" />
              <span>Entrada Inválida</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5">
              'abc' -&gt; recupera suavemente
            </span>
          </button>

          <button
            onClick={() => {
              restartProgram();
              runPresetSequence(['sair']);
            }}
            className="flex flex-col items-start p-2 rounded bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors group"
          >
            <div className="flex items-center gap-1.5 text-xs font-medium text-purple-400 group-hover:text-purple-300">
              <Play className="w-3 h-3 fill-current" />
              <span>Encerrar Programa</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5">
              digita 'sair' -&gt; exit 0
            </span>
          </button>
        </div>
      </div>

      {/* Helper Info Note */}
      <div className="flex items-start gap-2 text-xs text-slate-400 bg-slate-900/40 p-3 rounded-md border border-slate-800/60">
        <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <span className="text-slate-200 font-medium">Dica de Produtividade:</span> Você pode digitar diretamente no terminal com o teclado como em um terminal real Linux/macOS. Use <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px]">Enter</kbd> para submeter, as setas <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px]">↑</kbd> e <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px]">↓</kbd> para navegar pelo histórico de comandos, e <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px]">Ctrl+L</kbd> para limpar a tela.
        </div>
      </div>
    </div>
  );
};
