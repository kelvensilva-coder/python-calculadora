import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  History, 
  RotateCcw, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Delete, 
  Sliders, 
  Trash2,
  Maximize2,
  Smartphone,
  Monitor
} from 'lucide-react';
import { CalculatorMode, CalcOperation, HistoryItem } from '../types/calculator';
import { cleanFloatPrecision, evaluateBasic } from '../utils/calculatorLogic';
import { sound } from '../utils/audio';

export const TraditionalCalculator: React.FC = () => {
  // Calculator Display & Registers
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<CalcOperation>(null);
  const [waitingForNewOperand, setWaitingForNewOperand] = useState<boolean>(false);
  const [expression, setExpression] = useState<string>('');
  
  // Settings & Modes
  const [mode, setMode] = useState<CalculatorMode>('standard');
  const [deviceStyle, setDeviceStyle] = useState<'smartphone' | 'desktop'>('desktop');
  const [decimalSeparator, setDecimalSeparator] = useState<',' | '.'>(',');
  const [memory, setMemory] = useState<number>(0);
  const [hasMemory, setHasMemory] = useState<boolean>(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(true);
  
  // UI states
  const [soundActive, setSoundActive] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [activeOperator, setActiveOperator] = useState<CalcOperation>(null);
  const displayContainerRef = useRef<HTMLDivElement>(null);

  // Toggle Sound
  const toggleSound = () => {
    const next = !soundActive;
    setSoundActive(next);
    sound.enabled = next;
    if (next) sound.playSuccess();
  };

  // Helper to parse current display as float
  const getDisplayAsNumber = (val: string = displayValue): number => {
    return parseFloat(val.replace(',', '.'));
  };

  // Format number for display
  const formatNumberOutput = useCallback((num: number): string => {
    if (!isFinite(num)) return 'Erro';
    const cleaned = cleanFloatPrecision(num);
    const parts = cleaned.toString().split('.');
    
    // Format integer part with thousands separator
    const intPartFormatted = Number(parts[0]).toLocaleString(
      decimalSeparator === ',' ? 'pt-BR' : 'en-US'
    );
    
    if (parts[1] !== undefined) {
      return `${intPartFormatted}${decimalSeparator}${parts[1]}`;
    }
    return intPartFormatted;
  }, [decimalSeparator]);

  // Handle Digit Input (0-9)
  const inputDigit = useCallback((digit: string) => {
    sound.playKey();

    if (waitingForNewOperand) {
      setDisplayValue(digit);
      setWaitingForNewOperand(false);
    } else {
      if (displayValue === '0' || displayValue === 'Erro') {
        setDisplayValue(digit);
      } else {
        // Prevent exceeding reasonable screen limit
        if (displayValue.replace(/[^0-9]/g, '').length < 16) {
          setDisplayValue(displayValue + digit);
        }
      }
    }
    setActiveOperator(null);
  }, [displayValue, waitingForNewOperand]);

  // Handle Decimal Separator (, or .)
  const inputDecimal = useCallback(() => {
    sound.playKey();

    if (waitingForNewOperand) {
      setDisplayValue(`0${decimalSeparator}`);
      setWaitingForNewOperand(false);
      return;
    }

    if (!displayValue.includes(',') && !displayValue.includes('.')) {
      setDisplayValue(displayValue + decimalSeparator);
    }
  }, [displayValue, waitingForNewOperand, decimalSeparator]);

  // Clear / All Clear
  const clearAll = useCallback(() => {
    sound.playEnter();
    setDisplayValue('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewOperand(false);
    setExpression('');
    setActiveOperator(null);
  }, []);

  // Backspace (Delete last character)
  const handleBackspace = useCallback(() => {
    sound.playKey();
    if (waitingForNewOperand || displayValue === 'Erro') return;

    if (displayValue.length > 1) {
      const nextVal = displayValue.slice(0, -1);
      setDisplayValue(nextVal === '-' ? '0' : nextVal);
    } else {
      setDisplayValue('0');
    }
  }, [displayValue, waitingForNewOperand]);

  // Toggle Sign (±)
  const toggleSign = useCallback(() => {
    sound.playKey();
    if (displayValue === '0' || displayValue === 'Erro') return;

    const num = getDisplayAsNumber();
    setDisplayValue(formatNumberOutput(-num));
  }, [displayValue, formatNumberOutput]);

  // Percentage (%)
  const handlePercentage = useCallback(() => {
    sound.playKey();
    const current = getDisplayAsNumber();
    if (previousValue !== null && operation) {
      // e.g. 200 + 10% = 200 + (200 * 0.10)
      const percentVal = (previousValue * current) / 100;
      setDisplayValue(formatNumberOutput(percentVal));
    } else {
      setDisplayValue(formatNumberOutput(current / 100));
    }
  }, [displayValue, previousValue, operation, formatNumberOutput]);

  // Handle Basic Operations (+, −, ×, ÷)
  const performOperation = useCallback((nextOp: CalcOperation) => {
    sound.playKey();
    const inputValue = getDisplayAsNumber();

    if (previousValue === null) {
      setPreviousValue(inputValue);
      setExpression(`${formatNumberOutput(inputValue)} ${nextOp}`);
    } else if (operation) {
      if (!waitingForNewOperand) {
        try {
          const result = evaluateBasic(previousValue, inputValue, operation);
          setPreviousValue(result);
          setDisplayValue(formatNumberOutput(result));
          setExpression(`${formatNumberOutput(result)} ${nextOp}`);
        } catch {
          setDisplayValue('Erro');
          setPreviousValue(null);
          setOperation(null);
          setWaitingForNewOperand(true);
          sound.playError();
          return;
        }
      } else {
        setExpression(`${formatNumberOutput(previousValue)} ${nextOp}`);
      }
    }

    setWaitingForNewOperand(true);
    setOperation(nextOp);
    setActiveOperator(nextOp);
  }, [previousValue, operation, waitingForNewOperand, displayValue, formatNumberOutput]);

  // Perform Equals (=)
  const performEquals = useCallback(() => {
    sound.playEnter();
    if (previousValue === null || operation === null) return;

    const inputValue = getDisplayAsNumber();
    const fullExpr = `${expression} ${formatNumberOutput(inputValue)} =`;

    try {
      const result = evaluateBasic(previousValue, inputValue, operation);
      const formattedResult = formatNumberOutput(result);

      sound.playSuccess();
      setDisplayValue(formattedResult);
      setExpression(fullExpr);

      // Record in history tape
      const newHistoryItem: HistoryItem = {
        id: Math.random().toString(36).substring(2, 9),
        expression: fullExpr,
        result: formattedResult,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setHistory((prev) => [newHistoryItem, ...prev].slice(0, 50));

      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewOperand(true);
      setActiveOperator(null);
    } catch {
      setDisplayValue('Erro');
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewOperand(true);
      setActiveOperator(null);
      sound.playError();
    }
  }, [previousValue, operation, expression, displayValue, formatNumberOutput]);

  // Scientific Single-Operand Functions
  const performScientificUnary = (funcName: string) => {
    sound.playKey();
    const val = getDisplayAsNumber();
    let res: number;
    let label = '';

    switch (funcName) {
      case 'sqr': // x²
        res = cleanFloatPrecision(Math.pow(val, 2));
        label = `sqr(${formatNumberOutput(val)})`;
        break;
      case 'cube': // x³
        res = cleanFloatPrecision(Math.pow(val, 3));
        label = `cube(${formatNumberOutput(val)})`;
        break;
      case 'sqrt': // √x
        if (val < 0) {
          setDisplayValue('Erro');
          sound.playError();
          return;
        }
        res = cleanFloatPrecision(Math.sqrt(val));
        label = `√(${formatNumberOutput(val)})`;
        break;
      case 'inv': // 1/x
        if (val === 0) {
          setDisplayValue('Erro');
          sound.playError();
          return;
        }
        res = cleanFloatPrecision(1 / val);
        label = `1/(${formatNumberOutput(val)})`;
        break;
      case 'sin':
        res = cleanFloatPrecision(Math.sin((val * Math.PI) / 180));
        label = `sin(${formatNumberOutput(val)}°)`;
        break;
      case 'cos':
        res = cleanFloatPrecision(Math.cos((val * Math.PI) / 180));
        label = `cos(${formatNumberOutput(val)}°)`;
        break;
      case 'tan':
        res = cleanFloatPrecision(Math.tan((val * Math.PI) / 180));
        label = `tan(${formatNumberOutput(val)}°)`;
        break;
      case 'ln':
        if (val <= 0) {
          setDisplayValue('Erro');
          sound.playError();
          return;
        }
        res = cleanFloatPrecision(Math.log(val));
        label = `ln(${formatNumberOutput(val)})`;
        break;
      case 'log10':
        if (val <= 0) {
          setDisplayValue('Erro');
          sound.playError();
          return;
        }
        res = cleanFloatPrecision(Math.log10(val));
        label = `log(${formatNumberOutput(val)})`;
        break;
      case 'fact': {
        if (val < 0 || !Number.isInteger(val) || val > 170) {
          setDisplayValue('Erro');
          sound.playError();
          return;
        }
        let f = 1;
        for (let i = 2; i <= val; i++) f *= i;
        res = f;
        label = `${val}!`;
        break;
      }
      default:
        return;
    }

    const formattedRes = formatNumberOutput(res);
    setDisplayValue(formattedRes);
    setExpression(`${label} =`);
    setWaitingForNewOperand(true);

    setHistory((prev) => [
      {
        id: Math.random().toString(36).substring(2, 9),
        expression: `${label} =`,
        result: formattedRes,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      },
      ...prev,
    ]);
  };

  // Scientific Constants
  const insertConstant = (c: 'pi' | 'e') => {
    sound.playKey();
    const val = c === 'pi' ? Math.PI : Math.E;
    setDisplayValue(formatNumberOutput(val));
    setWaitingForNewOperand(true);
  };

  // Memory Functions
  const handleMemory = (action: 'MC' | 'MR' | 'M+' | 'M-') => {
    sound.playKey();
    const current = getDisplayAsNumber();

    switch (action) {
      case 'MC':
        setMemory(0);
        setHasMemory(false);
        break;
      case 'MR':
        if (hasMemory) {
          setDisplayValue(formatNumberOutput(memory));
          setWaitingForNewOperand(true);
        }
        break;
      case 'M+':
        setMemory((prev) => prev + current);
        setHasMemory(true);
        setWaitingForNewOperand(true);
        break;
      case 'M-':
        setMemory((prev) => prev - current);
        setHasMemory(true);
        setWaitingForNewOperand(true);
        break;
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is inside another form input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        inputDigit(e.key);
      } else if (e.key === '.' || e.key === ',') {
        e.preventDefault();
        inputDecimal();
      } else if (e.key === '+') {
        e.preventDefault();
        performOperation('+');
      } else if (e.key === '-') {
        e.preventDefault();
        performOperation('−');
      } else if (e.key === '*') {
        e.preventDefault();
        performOperation('×');
      } else if (e.key === '/') {
        e.preventDefault();
        performOperation('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        performEquals();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        clearAll();
      } else if (e.key === '%') {
        e.preventDefault();
        handlePercentage();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    inputDigit,
    inputDecimal,
    performOperation,
    performEquals,
    handleBackspace,
    clearAll,
    handlePercentage,
  ]);

  // Copy result to clipboard
  const copyDisplay = () => {
    navigator.clipboard.writeText(displayValue);
    setCopied(true);
    sound.playSuccess();
    setTimeout(() => setCopied(false), 1800);
  };

  // Compute adaptive font size for display
  const getDisplayFontSize = () => {
    const len = displayValue.length;
    if (len > 14) return 'text-2xl sm:text-3xl';
    if (len > 10) return 'text-3xl sm:text-4xl';
    if (len > 7) return 'text-4xl sm:text-5xl';
    return 'text-5xl sm:text-6xl';
  };

  return (
    <div className="space-y-4">
      {/* Top Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-900 border border-slate-800 p-3 rounded-lg">
        <div className="flex items-center gap-2">
          {/* Mode Selector */}
          <div className="flex items-center bg-slate-800 p-0.5 rounded-md">
            <button
              onClick={() => setMode('standard')}
              className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
                mode === 'standard' ? 'bg-emerald-600 text-white font-medium shadow-sm' : 'text-slate-300 hover:text-white'
              }`}
            >
              Padrão
            </button>
            <button
              onClick={() => setMode('scientific')}
              className={`px-3 py-1.5 rounded transition-colors whitespace-nowrap ${
                mode === 'scientific' ? 'bg-emerald-600 text-white font-medium shadow-sm' : 'text-slate-300 hover:text-white'
              }`}
            >
              Científica
            </button>
          </div>

          {/* Style Selector (Smartphone vs Desktop) */}
          <div className="hidden sm:flex items-center bg-slate-800 p-0.5 rounded-md">
            <button
              onClick={() => setDeviceStyle('desktop')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded transition-colors ${
                deviceStyle === 'desktop' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
              title="Layout estilo Calculadora de Computador (macOS / Windows)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Computador</span>
            </button>
            <button
              onClick={() => setDeviceStyle('smartphone')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded transition-colors ${
                deviceStyle === 'smartphone' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
              title="Layout estilo Calculadora de Celular (iOS / Android)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Celular</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Decimal Separator Toggle */}
          <button
            onClick={() => setDecimalSeparator((prev) => (prev === ',' ? '.' : ','))}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Alternar entre vírgula brasileira (,) e ponto internacional (.)"
          >
            <span>Decimal:</span>
            <span className="font-mono font-bold text-emerald-400">
              {decimalSeparator === ',' ? 'Vírgula (,)' : 'Ponto (.)'}
            </span>
          </button>

          {/* Audio Feedback Toggle */}
          <button
            onClick={toggleSound}
            className={`p-1.5 rounded-md border transition-colors ${
              soundActive
                ? 'bg-emerald-950/60 border-emerald-700 text-emerald-400'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
            }`}
            title={soundActive ? 'Efeitos Sonoros Ativos' : 'Efeitos Sonoros Mudos'}
          >
            {soundActive ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Toggle History Sidepanel */}
          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border transition-colors ${
              showHistory
                ? 'bg-slate-700 border-slate-600 text-white'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Histórico</span>
            {history.length > 0 && (
              <span className="font-mono text-[10px] bg-emerald-500 text-slate-950 font-bold px-1.5 py-0.2 rounded-full">
                {history.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Container: Calculator + History Sidepanel */}
      <div className="flex flex-col lg:flex-row items-start justify-center gap-6">
        
        {/* Physical Calculator Chassis */}
        <div 
          className={`w-full ${
            deviceStyle === 'smartphone' ? 'max-w-[360px]' : mode === 'scientific' ? 'max-w-[560px]' : 'max-w-[420px]'
          } mx-auto transition-all duration-200`}
        >
          <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl shadow-2xl p-5 space-y-4">
            
            {/* Window Controls Decorator (Mac/Smartphone style) */}
            <div className="flex items-center justify-between px-1 text-slate-500">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
              </div>
              <div className="flex items-center gap-2 text-[11px] font-mono tracking-wider text-slate-400">
                {hasMemory && (
                  <span className="text-emerald-400 font-semibold px-1 rounded bg-emerald-950/60 border border-emerald-800/40">
                    M: {cleanFloatPrecision(memory)}
                  </span>
                )}
                <span>{mode === 'scientific' ? 'CIENTÍFICA' : 'PADRÃO'}</span>
              </div>
            </div>

            {/* High-Fidelity Digital Screen */}
            <div 
              ref={displayContainerRef}
              className="relative bg-slate-950/90 rounded-2xl p-4 border border-slate-800/80 flex flex-col justify-end min-h-[110px] select-text group"
            >
              {/* Copy button overlay */}
              <button
                onClick={copyDisplay}
                className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white transition-opacity opacity-0 group-hover:opacity-100"
                title="Copiar valor atual"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>

              {/* Expression line */}
              <div className="text-right text-xs sm:text-sm font-mono text-slate-400 truncate tracking-wide h-6">
                {expression || '\u00A0'}
              </div>

              {/* Main value display */}
              <div className={`text-right font-mono font-bold text-white tracking-tight tabular-nums transition-all ${getDisplayFontSize()}`}>
                {displayValue}
              </div>
            </div>

            {/* Memory Toolbar Bar */}
            <div className="grid grid-cols-4 gap-2 text-xs font-semibold">
              <button
                onClick={() => handleMemory('MC')}
                disabled={!hasMemory}
                className="py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 disabled:opacity-30 text-slate-300 hover:text-white transition-colors"
              >
                MC
              </button>
              <button
                onClick={() => handleMemory('MR')}
                disabled={!hasMemory}
                className="py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 disabled:opacity-30 text-slate-300 hover:text-white transition-colors"
              >
                MR
              </button>
              <button
                onClick={() => handleMemory('M+')}
                className="py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                M+
              </button>
              <button
                onClick={() => handleMemory('M-')}
                className="py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                M-
              </button>
            </div>

            {/* Scientific Rows (when scientific mode is enabled) */}
            {mode === 'scientific' && (
              <div className="grid grid-cols-5 gap-2 pt-1 border-t border-slate-800/60">
                <button
                  onClick={() => performScientificUnary('sqr')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sky-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  x²
                </button>
                <button
                  onClick={() => performScientificUnary('cube')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sky-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  x³
                </button>
                <button
                  onClick={() => performScientificUnary('sqrt')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sky-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  √x
                </button>
                <button
                  onClick={() => performScientificUnary('inv')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sky-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  1/x
                </button>
                <button
                  onClick={() => performScientificUnary('fact')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sky-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  n!
                </button>

                <button
                  onClick={() => performScientificUnary('sin')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-purple-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  sin
                </button>
                <button
                  onClick={() => performScientificUnary('cos')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-purple-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  cos
                </button>
                <button
                  onClick={() => performScientificUnary('tan')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-purple-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  tan
                </button>
                <button
                  onClick={() => insertConstant('pi')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-purple-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  π
                </button>
                <button
                  onClick={() => insertConstant('e')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-purple-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  e
                </button>

                <button
                  onClick={() => performScientificUnary('ln')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-indigo-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  ln
                </button>
                <button
                  onClick={() => performScientificUnary('log10')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-indigo-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  log
                </button>
                <button
                  onClick={() => {
                    sound.playKey();
                    setDisplayValue(formatNumberOutput(cleanFloatPrecision(Math.pow(10, getDisplayAsNumber()))));
                    setWaitingForNewOperand(true);
                  }}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-indigo-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  10ˣ
                </button>
                <button
                  onClick={() => {
                    sound.playKey();
                    setDisplayValue(formatNumberOutput(cleanFloatPrecision(Math.pow(getDisplayAsNumber(), 2))));
                    setWaitingForNewOperand(true);
                  }}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-indigo-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  yˣ
                </button>
                <button
                  onClick={handlePercentage}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-amber-300 text-xs font-mono font-medium transition-transform active:scale-95"
                >
                  %
                </button>
              </div>
            )}

            {/* Standard Keypad Grid */}
            <div className="grid grid-cols-4 gap-2.5">
              {/* Row 1: Function Keys */}
              <button
                onClick={clearAll}
                className="py-3.5 sm:py-4 rounded-2xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/40 font-bold text-base sm:text-lg transition-transform active:scale-95"
              >
                {displayValue !== '0' ? 'C' : 'AC'}
              </button>
              <button
                onClick={toggleSign}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800 hover:bg-slate-700/90 text-slate-200 border border-slate-700/50 font-bold text-base sm:text-lg transition-transform active:scale-95"
              >
                ±
              </button>
              <button
                onClick={handlePercentage}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800 hover:bg-slate-700/90 text-slate-200 border border-slate-700/50 font-bold text-base sm:text-lg transition-transform active:scale-95"
              >
                %
              </button>
              <button
                onClick={() => performOperation('÷')}
                className={`py-3.5 sm:py-4 rounded-2xl border font-bold text-xl transition-all active:scale-95 ${
                  activeOperator === '÷'
                    ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500/60'
                }`}
              >
                ÷
              </button>

              {/* Row 2: 7, 8, 9, × */}
              <button
                onClick={() => inputDigit('7')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                7
              </button>
              <button
                onClick={() => inputDigit('8')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                8
              </button>
              <button
                onClick={() => inputDigit('9')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                9
              </button>
              <button
                onClick={() => performOperation('×')}
                className={`py-3.5 sm:py-4 rounded-2xl border font-bold text-xl transition-all active:scale-95 ${
                  activeOperator === '×'
                    ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500/60'
                }`}
              >
                ×
              </button>

              {/* Row 3: 4, 5, 6, − */}
              <button
                onClick={() => inputDigit('4')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                4
              </button>
              <button
                onClick={() => inputDigit('5')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                5
              </button>
              <button
                onClick={() => inputDigit('6')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                6
              </button>
              <button
                onClick={() => performOperation('−')}
                className={`py-3.5 sm:py-4 rounded-2xl border font-bold text-xl transition-all active:scale-95 ${
                  activeOperator === '−'
                    ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500/60'
                }`}
              >
                −
              </button>

              {/* Row 4: 1, 2, 3, + */}
              <button
                onClick={() => inputDigit('1')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                1
              </button>
              <button
                onClick={() => inputDigit('2')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                2
              </button>
              <button
                onClick={() => inputDigit('3')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                3
              </button>
              <button
                onClick={() => performOperation('+')}
                className={`py-3.5 sm:py-4 rounded-2xl border font-bold text-xl transition-all active:scale-95 ${
                  activeOperator === '+'
                    ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500/60'
                }`}
              >
                +
              </button>

              {/* Row 5: 0, Decimal Separator, Backspace, Equals */}
              <button
                onClick={() => inputDigit('0')}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-semibold text-lg sm:text-xl transition-transform active:scale-95"
              >
                0
              </button>
              <button
                onClick={inputDecimal}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white border border-slate-700/40 font-bold text-lg sm:text-xl transition-transform active:scale-95"
              >
                {decimalSeparator}
              </button>
              <button
                onClick={handleBackspace}
                className="py-3.5 sm:py-4 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700/40 font-semibold flex items-center justify-center transition-transform active:scale-95"
                title="Apagar último dígito (Backspace)"
              >
                <Delete className="w-5 h-5" />
              </button>
              <button
                onClick={performEquals}
                className="py-3.5 sm:py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 border border-emerald-400/60 font-bold text-2xl transition-transform active:scale-95 shadow-lg shadow-emerald-950/50"
              >
                =
              </button>
            </div>
          </div>
        </div>

        {/* History Tape Sidepanel */}
        {showHistory && (
          <div className="w-full lg:w-80 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Fita de Histórico</h3>
              </div>
              {history.length > 0 && (
                <button
                  onClick={() => setHistory([])}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-rose-400 transition-colors"
                  title="Limpar histórico"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Limpar</span>
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400 space-y-1">
                <p>Nenhum cálculo registrado ainda.</p>
                <p className="text-[11px] text-slate-400">
                  Os cálculos concluídos aparecerão aqui.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[460px] overflow-y-auto terminal-scroll pr-1">
                {history.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      sound.playKey();
                      setDisplayValue(item.result);
                      setWaitingForNewOperand(true);
                    }}
                    className="w-full p-2.5 rounded-xl bg-slate-950/60 hover:bg-slate-800/70 border border-slate-800/80 text-right group transition-colors"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>{item.timestamp}</span>
                      <span className="truncate max-w-[170px]">{item.expression}</span>
                    </div>
                    <div className="text-base font-mono font-bold text-emerald-400 group-hover:text-emerald-300 mt-1">
                      = {item.result}
                    </div>
                  </button>
                ))}
              </div>
            )}

            <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-800/60">
              Clique em qualquer cálculo anterior para reutilizar o resultado na tela.
            </div>
          </div>
        )}
      </div>

      {/* Keyboard Shortcuts Hint */}
      <div className="max-w-xl mx-auto text-center text-xs text-slate-400 bg-slate-900/40 p-2.5 rounded-lg border border-slate-800/60">
        <span className="text-slate-300 font-medium">Suporte a Teclado Físico:</span> Digite números <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">0-9</kbd>, operadores <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">+</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">-</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">*</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">/</kbd>, vírgula/ponto, <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">Enter</kbd> para calcular, <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">Backspace</kbd> e <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[10px]">Esc</kbd> para limpar.
      </div>
    </div>
  );
};
