import React from 'react';
import { BookOpen, CheckCircle2, Code2, Terminal, Cpu, ArrowRight } from 'lucide-react';
import { ARCHITECTURE_SECTIONS } from '../data/pythonCode';

export const ArchitectureGuide: React.FC = () => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Intro Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center gap-3 mb-2">
          <BookOpen className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-white">
            Documentação Técnica & Princípios de Engenharia de Software
          </h2>
        </div>
        <p className="text-sm text-slate-300 leading-relaxed">
          Esta documentação detalha as decisões arquiteturais tomadas para implementar a calculadora interativa em Python, 
          cumprindo com rigor todos os requisitos funcionais, técnicos e os padrões internacionais da comunidade (PEP 8, Clean Code e tipagem estrita).
        </p>
      </div>

      {/* 4 Core Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {ARCHITECTURE_SECTIONS.map((sec) => (
          <div key={sec.id} className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded">
                {sec.badge}
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>

            <div>
              <h3 className="text-sm font-semibold text-white">
                {sec.title}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {sec.description}
              </p>
            </div>

            <div className="text-xs text-slate-300 leading-relaxed whitespace-pre-line bg-slate-950/50 p-3 rounded border border-slate-800/60">
              {sec.solution}
            </div>

            <div className="space-y-1">
              <span className="text-[11px] text-slate-400 font-mono">Implementação:</span>
              <pre className="p-2.5 bg-slate-950 rounded border border-slate-800 text-xs font-mono text-purple-300 overflow-x-auto terminal-scroll">
                {sec.codeSnippet}
              </pre>
            </div>
          </div>
        ))}
      </div>

      {/* Senior Engineering Best Practices */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center gap-2 text-white font-semibold text-sm">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <span>Boas Práticas de Engenharia Aplicadas (Clean Code & PEP 8)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-950/60 rounded border border-slate-800/80 space-y-1">
            <span className="font-semibold text-emerald-400">1. Princípio da Responsabilidade Única (SRP)</span>
            <p className="text-slate-400 leading-relaxed">
              Cada função executa exclusivamente uma tarefa bem delimitada: conversão, entrada, cálculo ou formatação.
            </p>
          </div>

          <div className="p-3 bg-slate-950/60 rounded border border-slate-800/80 space-y-1">
            <span className="font-semibold text-sky-400">2. Type Hints e Docstrings (PEP 484 & PEP 257)</span>
            <p className="text-slate-400 leading-relaxed">
              Todas as funções possuem anotações de tipo (<code className="text-slate-300">float</code>, <code className="text-slate-300">str</code>, <code className="text-slate-300">Callable</code>) e docstrings explicativas no padrão Google/Sphinx.
            </p>
          </div>

          <div className="p-3 bg-slate-950/60 rounded border border-slate-800/80 space-y-1">
            <span className="font-semibold text-purple-400">3. Filosofia EAFP do Python</span>
            <p className="text-slate-400 leading-relaxed">
              <em>&ldquo;Easier to Ask for Forgiveness than Permission&rdquo;</em>: Utiliza blocos <code className="text-slate-300">try/except</code> para tratar exceções em vez de regex frágeis ou checagens custosas.
            </p>
          </div>
        </div>
      </div>

      {/* Execution Instructions */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex items-center gap-2 text-white font-semibold text-sm">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>Como Executar Localmente no seu Computador</span>
        </div>

        <div className="space-y-2 text-xs text-slate-300">
          <p>
            1. Baixe o arquivo <code className="text-emerald-400 font-mono">calculadora.py</code> (usando o botão &ldquo;Baixar Script .py&rdquo; no canto superior direito).
          </p>
          <p>
            2. Abra o terminal (Prompt de Comando, PowerShell, Terminal macOS ou Linux) na pasta do arquivo e execute:
          </p>
          <pre className="p-3 bg-slate-950 rounded border border-slate-800 font-mono text-emerald-400 text-xs">
            python3 calculadora.py
          </pre>
          <p>
            3. Para rodar a suíte de testes automatizada via terminal:
          </p>
          <pre className="p-3 bg-slate-950 rounded border border-slate-800 font-mono text-emerald-400 text-xs">
            python3 -m unittest test_calculadora.py -v
          </pre>
        </div>
      </div>
    </div>
  );
};
