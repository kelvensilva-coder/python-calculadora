export type CalculatorMode = 'standard' | 'scientific';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: string;
}

export type CalcOperation = '+' | '−' | '×' | '÷' | null;

export interface CalculatorState {
  displayValue: string;
  previousValue: number | null;
  operation: CalcOperation;
  waitingForNewOperand: boolean;
  expression: string;
  memory: number;
  history: HistoryItem[];
  mode: CalculatorMode;
  decimalSeparator: ',' | '.';
}
