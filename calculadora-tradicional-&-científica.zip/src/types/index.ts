export type TerminalTheme = 'dark' | 'matrix' | 'dracula' | 'amber';

export interface TerminalLine {
  id: string;
  type: 'system' | 'prompt' | 'input' | 'output' | 'error' | 'success' | 'divider' | 'menu';
  text: string;
  timestamp?: string;
  highlight?: boolean;
}

export type CalcStep = 
  | 'SELECT_OPTION'
  | 'INPUT_NUM1'
  | 'INPUT_NUM2'
  | 'TERMINATED';

export interface OperationConfig {
  symbol: string;
  name: string;
  calc: (a: number, b: number) => number;
}

export interface UnitTestItem {
  id: string;
  name: string;
  category: 'Parsing & Normalização' | 'Operações Aritméticas' | 'Tratamento de Exceções' | 'Formatação de Saída';
  description: string;
  expected: string;
  run: () => { passed: boolean; actual: string; details?: string };
}
