export const CALCULADORA_PY = `"""
Calculadora Interativa via Terminal em Python
----------------------------------------------
Autor: Engenheiro de Software Python Sênior
Descrição:
    Calculadora interativa via linha de comando para as 4 operações básicas,
    com suporte a formatação numérica flexível (ponto e vírgula),
    tratamento resiliente de exceções (ValueError, ZeroDivisionError),
    loop contínuo e formatação inteligente de resultados.
Padrão: PEP 8 / Clean Code / Python 3.10+
"""

from typing import Callable, Dict, Tuple
import sys


def converter_para_float(entrada: str) -> float:
    """
    Normaliza a string fornecida e converte para float.
    
    Substitui automaticamente vírgulas (',') por pontos ('.') antes
    da conversão para aceitar tanto a notação decimal brasileira quanto
    a internacional.
    
    Args:
        entrada (str): Texto inserido pelo usuário.
        
    Returns:
        float: Valor numérico convertido.
        
    Raises:
        ValueError: Se a string não puder ser convertida em float.
    """
    # Remove espaços em branco laterais e substitui vírgula por ponto
    entrada_limpa = entrada.strip().replace(",", ".")
    return float(entrada_limpa)


def solicitar_numero(mensagem: str) -> float:
    """
    Solicita um número ao usuário via terminal de forma segura.
    
    Mantém um loop de repetição até que uma entrada válida seja fornecida,
    tratando a exceção ValueError sem abortar a execução do programa.
    
    Args:
        mensagem (str): Mensagem de prompt exibida ao usuário.
        
    Returns:
        float: Número válido validado e convertido.
    """
    while True:
        entrada = input(mensagem)
        try:
            return converter_para_float(entrada)
        except ValueError:
            print(f"\\n  [ERRO DE ENTRADA] '{entrada.strip()}' não é um número válido!")
            print("  Por favor, digite um número inteiro ou decimal (Ex: 10, 10.5, 10,5, -3)")
            print("  Tente novamente.\\n")


def somar(a: float, b: float) -> float:
    """Calcula a soma de dois números."""
    return a + b


def subtrair(a: float, b: float) -> float:
    """Calcula a subtração entre dois números (a - b)."""
    return a - b


def multiplicar(a: float, b: float) -> float:
    """Calcula a multiplicação de dois números."""
    return a * b


def dividir(a: float, b: float) -> float:
    """
    Calcula a divisão de a por b.
    
    Raises:
        ZeroDivisionError: Se o divisor (b) for igual a zero.
    """
    if b == 0:
        raise ZeroDivisionError("Divisão por zero não é permitida.")
    return a / b


def formatar_resultado(valor: float) -> str:
    """
    Formata o resultado final de acordo com a especificação técnica:
    - Se o número for inteiro (ex: 4.0), exibe como inteiro ('4').
    - Se o número for decimal (ex: 3.33333), exibe com até 2 casas decimais ('3.33').
    
    Args:
        valor (float): Número em ponto flutuante a ser formatado.
        
    Returns:
        str: Representação em texto devidamente formatada.
    """
    # Verifica se a parte fracionária é nula (ex: 12.0 -> True)
    if valor.is_integer():
        return str(int(valor))
    
    # Formata com até 2 casas decimais
    return f"{valor:.2f}"


def exibir_cabecalho() -> None:
    """Imprime o cabeçalho estilizado da aplicação."""
    print("=" * 54)
    print("         CALCULADORA INTERATIVA VIA TERMINAL")
    print("=" * 54)


def exibir_menu() -> None:
    """Apresenta o menu de operações com layout limpo e legível."""
    print("\\n" + "-" * 54)
    print("  OPERAÇÕES DISPONÍVEIS:")
    print("  [1] Adição (+)")
    print("  [2] Subtração (-)")
    print("  [3] Multiplicação (*)")
    print("  [4] Divisão (/)")
    print("  [5] Sair do Programa (ou digite 'sair')")
    print("-" * 54)


def executar_calculadora() -> None:
    """
    Função principal que orquestra o fluxo interativo do programa.
    Executa em loop contínuo (while True) até a saída expressa do usuário.
    """
    exibir_cabecalho()
    
    # Mapeamento declarativo de operações (Open/Closed Principle)
    # Formato: chave -> (símbolo, função executora, nome amigável)
    operacoes: Dict[str, Tuple[str, Callable[[float, float], float], str]] = {
        "1": ("+", somar, "Adição"),
        "2": ("-", subtrair, "Subtração"),
        "3": ("*", multiplicar, "Multiplicação"),
        "4": ("/", dividir, "Divisão"),
    }
    
    while True:
        exibir_menu()
        opcao = input(">> Digite a opção desejada (1-5 ou 'sair'): ").strip().lower()
        
        # 1. Verificação de Saída
        if opcao in ("5", "sair", "exit", "q", "quit"):
            print("\\n" + "=" * 54)
            print("  Programa finalizado com sucesso. Até logo!")
            print("=" * 54 + "\\n")
            break
            
        # 2. Validação da Opção do Menu
        if opcao not in operacoes:
            print(f"\\n  [OPÇÃO INVÁLIDA] '{opcao}' não foi reconhecida.")
            print("  Escolha um número entre 1 e 5 ou digite 'sair'.")
            continue
            
        simbolo, funcao_calculo, nome_operacao = operacoes[opcao]
        print(f"\\n>> Operação Selecionada: {nome_operacao} ({simbolo})")
        
        # 3. Leitura do Primeiro Operando
        num1 = solicitar_numero(">> Digite o primeiro número: ")
        
        # 4. Leitura do Segundo Operando com proteção contínua contra Divisão por Zero
        while True:
            num2 = solicitar_numero(">> Digite o segundo número: ")
            
            try:
                resultado = funcao_calculo(num1, num2)
                
                # Formatação dos operandos e do resultado
                n1_fmt = formatar_resultado(num1)
                n2_fmt = formatar_resultado(num2)
                res_fmt = formatar_resultado(resultado)
                
                print("\\n" + "=" * 54)
                print(f"  RESULTADO: {n1_fmt} {simbolo} {n2_fmt} = {res_fmt}")
                print("=" * 54)
                break  # Sai do loop do segundo número e retorna ao menu principal
                
            except ZeroDivisionError:
                print("\\n  [ERRO DE ARITMÉTICA] Não é possível dividir um número por zero (0)!")
                print("  Por favor, digite um divisor válido diferente de zero.")
                # Continua solicitando o num2 sem forçar o usuário a redigitar o num1


if __name__ == "__main__":
    try:
        executar_calculadora()
    except KeyboardInterrupt:
        print("\\n\\nOperação cancelada pelo usuário (Ctrl+C). Encerrando...")
        sys.exit(0)
`;

export const TEST_CALCULADORA_PY = `"""
Suíte de Testes Automatizados para a Calculadora Interativa
------------------------------------------------------------
Executa testes unitários cobrindo todos os requisitos funcionais:
- Conversão flexível de vírgula e ponto
- Tratamento de ValueError para entradas inválidas
- Precisão das operações básicas (+, -, *, /)
- Tratamento de ZeroDivisionError
- Formatação de inteiros e decimais (até 2 casas)
"""

import unittest
from calculadora import (
    converter_para_float,
    somar,
    subtrair,
    multiplicar,
    dividir,
    formatar_resultado,
)


class TestCalculadora(unittest.TestCase):
    
    # ---------------------------------------------------------
    # 1. Testes de Suporte a Numeração Flexível
    # ---------------------------------------------------------
    def test_conversao_com_virgula(self):
        """Aceita valores decimais com vírgula padrão brasileiro."""
        self.assertEqual(converter_para_float("10,5"), 10.5)
        self.assertEqual(converter_para_float("0,25"), 0.25)
        self.assertEqual(converter_para_float("-3,7"), -3.7)

    def test_conversao_com_ponto(self):
        """Aceita valores decimais com ponto padrão internacional."""
        self.assertEqual(converter_para_float("10.5"), 10.5)
        self.assertEqual(converter_para_float("100.0"), 100.0)

    def test_conversao_inteiro(self):
        """Aceita números inteiros como string."""
        self.assertEqual(converter_para_float("42"), 42.0)
        self.assertEqual(converter_para_float("-7"), -7.0)

    def test_conversao_com_espacos(self):
        """Trata espaços em branco antes ou depois da entrada."""
        self.assertEqual(converter_para_float("  15,4  "), 15.4)

    # ---------------------------------------------------------
    # 2. Testes de Tratamento de Erros e Exceções
    # ---------------------------------------------------------
    def test_entrada_invalida_lanca_value_error(self):
        """Entradas não numéricas devem levantar ValueError sem quebrar o sistema."""
        with self.assertRaises(ValueError):
            converter_para_float("abc")
        with self.assertRaises(ValueError):
            converter_para_float("12.34.56")
        with self.assertRaises(ValueError):
            converter_para_float("")

    def test_divisao_por_zero_lanca_excecao(self):
        """Divisão por zero deve levantar ZeroDivisionError explicitamente."""
        with self.assertRaises(ZeroDivisionError):
            dividir(10.0, 0.0)
        with self.assertRaises(ZeroDivisionError):
            dividir(-5.0, 0)

    # ---------------------------------------------------------
    # 3. Testes das Operações Aritméticas
    # ---------------------------------------------------------
    def test_somar(self):
        self.assertEqual(somar(10.5, 2.5), 13.0)
        self.assertEqual(somar(-5.0, 5.0), 0.0)

    def test_subtrair(self):
        self.assertEqual(subtrair(10.5, 3.2), 7.3)
        self.assertEqual(subtrair(5.0, 10.0), -5.0)

    def test_multiplicar(self):
        self.assertEqual(multiplicar(4.0, 2.5), 10.0)
        self.assertEqual(multiplicar(-3.0, 3.0), -9.0)

    def test_dividir_sucesso(self):
        self.assertEqual(dividir(10.0, 2.0), 5.0)
        self.assertAlmostEqual(dividir(10.0, 3.0), 3.3333333333333335)

    # ---------------------------------------------------------
    # 4. Testes de Formatação do Resultado
    # ---------------------------------------------------------
    def test_formatar_resultado_inteiro(self):
        """Valores matematicamente inteiros devem ser exibidos sem '.0'."""
        self.assertEqual(formatar_resultado(13.0), "13")
        self.assertEqual(formatar_resultado(0.0), "0")
        self.assertEqual(formatar_resultado(-5.0), "-5")

    def test_formatar_resultado_decimal(self):
        """Valores com decimais devem ser arredondados para até 2 casas."""
        self.assertEqual(formatar_resultado(3.333333), "3.33")
        self.assertEqual(formatar_resultado(10.5), "10.50")
        self.assertEqual(formatar_resultado(7.126), "7.13")


if __name__ == "__main__":
    unittest.main()
`;

export const ARCHITECTURE_SECTIONS = [
  {
    id: 'req1',
    badge: 'Requisito 1',
    title: 'Suporte a Numeração Flexível (Vírgula e Ponto)',
    description: 'Como aceitar 10, 10.5 e 10,5 sem disparar ValueError',
    solution: `No Python nativo, a função float("10,5") lança imediatamente ValueError: could not convert string to float: '10,5'.
Para resolver isso de forma resiliente:
1. Normalizamos a entrada com .strip() (removendo espaços acidentais).
2. Substituímos a vírgula por ponto: .replace(",", ".").
3. Convertemos para float(): float("10,5".strip().replace(",", ".")) -> 10.5.`,
    codeSnippet: `def converter_para_float(entrada: str) -> float:
    entrada_limpa = entrada.strip().replace(",", ".")
    return float(entrada_limpa)`
  },
  {
    id: 'req2',
    badge: 'Requisito 2',
    title: 'Tratamento Defensivo de Erros & ZeroDivisionError',
    description: 'Validação em loop contínuo e proteção contra crash',
    solution: `Em vez de deixar a exceção quebrar o terminal com traceback feio:
1. A função solicitar_numero() encapsula um loop while True com bloco try/except ValueError. Se a conversão falhar, exibe uma mensagem amigável e solicita o número novamente.
2. Na divisão por zero, a função dividir() lança ZeroDivisionError. O chamador captura a exceção, exibe aviso claro e solicita apenas o divisor novamente, preservando o dividendo informado!`,
    codeSnippet: `while True:
    num2 = solicitar_numero(">> Digite o segundo número: ")
    try:
        resultado = funcao_calculo(num1, num2)
        break
    except ZeroDivisionError:
        print("[ERRO DE ARITMÉTICA] Não é possível dividir por zero!")`
  },
  {
    id: 'req3',
    badge: 'Requisito 3',
    title: 'Fluxo Interativo e Menu com Saída Clara',
    description: 'Loop while, menu estruturado e encerramento limpo',
    solution: `A função executar_calculadora() mantém um loop while True ativo.
Para a saída:
- Aceita '5', 'sair', 'exit', 'q' ou 'quit' de forma insensível a maiúsculas (.strip().lower()).
- Permite interromper via teclado com KeyboardInterrupt (Ctrl+C).
- Usa dicionário de operações (dispatch table) para mapeamento limpo de funções sem cadeias gigantes de if/elif.`,
    codeSnippet: `if opcao in ("5", "sair", "exit", "q", "quit"):
    print("Programa finalizado com sucesso. Até logo!")
    break`
  },
  {
    id: 'req4',
    badge: 'Requisito 4',
    title: 'Qualidade de Código & Formatação Inteligente',
    description: 'Inteiros limpos e decimais com até 2 casas decimais',
    solution: `Em Python, o método float.is_integer() verifica se o número não possui parte fracionária:
- 13.0.is_integer() retorna True -> exibido como str(int(13.0)) -> "13"
- 3.3333.is_integer() retorna False -> formatado via f-string f"{valor:.2f}" -> "3.33"
Isso atende com máxima elegância ao requisito de exibir como inteiro quando o resultado é exato.`,
    codeSnippet: `def formatar_resultado(valor: float) -> str:
    if valor.is_integer():
        return str(int(valor))
    return f"{valor:.2f}"`
  }
];
